group 1
http://dblp.uni-trier.de/pers/hd/j/Jordan:Michael_I=
Leader: Michael I. Jordan
与其合作发论文的UCB的人
若以 # 开始，则代表不是UCB的人
存疑： #Andrew Y. Ng (12) 曾经是jordan的学生，但是现在学校写 的斯坦福
目前截止到合作关系 （3）


g1 人工智能
数据来自jordan 的主页
有的数据带，
 line.split(',')[0]


group 2
http://dblp.uni-trier.de/pers/hd/y/Yu:Philip_S=
Philip S. Yu
问题： 合作关系和师生关系难界定，chuanshi和binwu都和yu有合作，但是一个是访学学生
目前截止到合作关系 （8）


g2 数据挖掘
书记来自http://bdsc.lab.uic.edu/people.html


g3  计算机视觉
feifei li 

line.split(' PhD')[0]
